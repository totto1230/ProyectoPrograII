package proyectoprogramacióngrafic_1;

public class Main {

    public static void main(String[] args) {
        //Declaraciön de objetos

        Grafic g = new Grafic();
        g.graphic();

    }

}
